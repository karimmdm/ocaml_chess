# INSTALL

### Packages to install for game
1. Install XQuartz 2.7.11
2. brew install libpng pkg-config
4. opam install graphics base cppo dune dune-configurator ocaml ocamlfind stdio camlimages yojson curly dotenv

### Packages to install for server
1. brew install libev
2. opam install opium yojson ppx_deriving_yojson

### Running the program
1. make play
2. click on squares to see the location clicked
3. cmd + c or ctrl + c to close program
